run_benchmark_sim=function(S=0.4,N=5e4,divrate_per_year=1,nyears_driver_acquisition = 10,nyears = 33,minprop=0.05){
  run_selection_sim(0.1,
                    final_division_rate = divrate_per_year/365,
                    target_pop_size = N,
                    nyears_driver_acquisition = nyears_driver_acquisition,
                    nyears = nyears,fitness=log(1+S)/(divrate_per_year),
                    minprop = minprop)
}
get_subsampled_tree_fixed_prop=function(selsim,N=100,nmut=10){
  mutants=which(selsim$edge[,2]<=length(selsim$tip.label) & selsim$driverid>0 & selsim$state>0)
  wt=which(selsim$edge[,2]<=length(selsim$tip.label) & selsim$driverid==0 & selsim$state>0)
  outgroup=which(selsim$edge[,2]<=length(selsim$tip.label) & selsim$state==0)
  tips=selsim$edge[c(sample(mutants,nmut,replace = FALSE),sample(wt,N-nmut,replace=FALSE),outgroup),2]
  get_subsampled_tree(selsim,-1,tips)
}
get_subtree_simple=function(selsim,N,nmut){
  st=get_subsampled_tree_fixed_prop(selsim,N=N,nmut = nmut)
  st=get_elapsed_time_tree(st)
  st$edge.length=st$edge.length/365 ## Show in years.
  list(st=st)
}
get_subtree_simple_unbiased=function(selsim,N){
  st=get_subsampled_tree(selsim,N)
  st=get_elapsed_time_tree(st)
  st$edge.length=st$edge.length/365 ## Show in years.
  list(st=st)
}

run_test=function(){
  
  sid=12345
  rsimpop:::initSimPop(sid,bForce=TRUE)
  s=11
  S=exp(s)-1
  N=1e5
  nmut=200
  cat("S=",S,"s=",s,"\n")
  dpy=1
  #set nyear such that 99% of the time the pure birthdeath would have a clone size=N.
  ##. N ~ exp(st)*Exp(rate=s/(1+s))
  ## Solve cumulative distribution=p: 1-exp(rate*N*exp(-st))=1-p
  gett=function(s,N,p=0.9) -(1/s)*log(-log(p)/(N*(s/(1+s))))
  nyd=5## Year that the driver is acquired.
  ##
  nyear=nyd+gett(s,N,p=0.9)
selsim=run_benchmark_sim(S=S,divrate_per_year = dpy,N = N,nyears_driver_acquisition = nyd,nyear=nyear,minprop = 0.5)
selsim$driver.per.compartment
max(selsim$driver.per.compartment$pop.size)
max(selsim$driver.per.compartment$pop.size)
cfg=addCellCompartment(selsim$cfg,population=1e3,rate=0.002739726,descr="Post-TKI-Driver")
idx=which(selsim$driverid==1 & selsim$edge[,2]<=Ntip(selsim))
selsim$state[idx]=2
selsim$events=rbind(selsim$events,
                    data.frame(value=2,
                               driverid=1,
                               node=selsim$edge[idx,2],
                               ts=max(selsim$timestamp),
                               uid=max(selsim$events$uid)+1:length(idx))
)
selsim$currentEventUID=max(selsim$event$uid)
cfg$compartment$popsize[3]=1e5
cfg$compartment$death_rate[3]=3*cfg$compartment$rate[3]
cfg
cfg$info$population[4]=cfg$info$population[3]
cfg$info$population[3]=0
cfg$info$id[4]=1
params = selsim$params
params[["n_sim_days"]] = (nyear+2)* 365
params[["maxt"]] = NULL
#browser()
selsim2 = sim_pop(selsim %>% (function(x) {x$cfg=cfg;x}), params = params, cfg)
#browser()
}
run_test2=function(){
  selsim=run_benchmark_sim(S=S,divrate_per_year = dpy,N = N,nyears_driver_acquisition = nyd,nyear=nyear,minprop = 0.5)
  params = selsim$params
  params[["n_sim_days"]] = round((nyear+0.1)* 365)
  params[["maxt"]] = NULL
  selsim2 = sim_pop(selsim, params = params, selsim$cfg)
  browser()
}
